from getpass import getpass
from zipfile import ZipFile
from Crypto.Cipher import AES
from Crypto import Random
import requests
import os
URL = "http://secret-dawn-5277.herokuapp.com"

sym_key = "1234567812345678"

def encrypt_file(file_name, symmetric_key):
    encrypted = False

    with open(file_name, 'rb') as in_file:
        with open('{0}.enc'.format(file_name), 'wb') as out_file:
            while True:
                chunk = in_file.read(8192)

                if len(chunk) == 0:
                    break
                elif len(chunk) % 16 != 0:
                    chunk += ' '.encode() * (16 - len(chunk) % 16)

                out_file.write(symmetric_key.encrypt(chunk))

        encrypted = True

    return encrypted

def decrypt_file(in_name, out_name, symmetric_key):
    decrypted = False
    with open(in_name, 'rb') as in_file:
        with open(out_name, 'wb') as out_file:
            while True:
                chunk = in_file.read(8192)

                if len(chunk) == 0:
                    break

                out_file.write(symmetric_key.decrypt(chunk))

        decrypted = True
    os.remove(in_name)
    return decrypted

def download():

    logged_in = False
    session = requests.Session()
    for i in range(3):
        resp = session.get(URL)
        cookie = resp.headers['Set-Cookie']
        csrf = cookie.split(';')[0].split('=')[1].encode()
        username = input('Username: ')
        password = getpass('Password: ')
        data = {'username': username, 'password': password, 'csrfmiddlewaretoken':csrf}
        resp = session.post(URL, data=data)
        if 'homepage' in resp.url:
            logged_in = True
            break
    if logged_in:
        resp = session.get(URL+"/homepage/2", stream=True)
        data = resp.text.split('\n')
        myReports = {}
        sharedReports = {}
        publicReports = {}
        for line in data:
            if 'hidden' in line:
                fields = line.strip().split()
                params = fields[2].split('_')[1:]
                if params[0] == 'report':
                    if params[1] == 'mine':
                        myReports[params[2]] = (params[3], [])
                    if params[1] == 'shared':
                        sharedReports[params[2]] = (params[3], [])
                if params[0] == 'file':
                    if params[1] in myReports:
                        (name, files) = myReports[params[1]]
                        if params[3] == "True":
                            files.append((params[2], True))
                        else:
                            files.append((params[2], False))
                        myReports[params[1]] = (name, files)
                    if params[1] in sharedReports:
                        (name, files) = sharedReports[params[1]]
                        if params[3] == "True":
                            files.append((params[2], True))
                        else:
                            files.append((params[2], False))
                        sharedReports[params[1]] = (name, files)
    else:
        print("Login failed")
    if (len(myReports)+len(sharedReports)+len(publicReports)) == 0:
        print("No reports available")

    i = 0
    reports = []
    if len(myReports) > 0:
        print("My Reports")
        for pk in myReports:
           print('{0}: {1}'.format(i, myReports[pk][0]))
           reports.append((pk, myReports[pk]))
           i += 1
    if len(sharedReports) > 0:
        print("\n\nShared Reports")
        for pk in sharedReports:
           print('{0}: {1}'.format(i, sharedReports[pk][0]))
           reports.append((pk, sharedReports[pk]))
           i += 1
    if len(publicReports) > 0:
        print("\n\nPublic Reports")
        for pk in publicReports:
           print('{0}: {1}'.format(i, publicReports[pk]))
           reports.append((pk, publicReports[pk]))
           i += 1
    print('\nTo download a report, enter the number of the report in the list: ')
    report_index = int(input('Number: '))
    try:
        report = reports[report_index]
        encrypted = report[1][1]
        resp = session.get(URL+'/download/'+str(report[0]), stream=True)
        header = resp.headers['content-disposition']
        index = header.find("filename=")
        filename = header[index+9:]
        with open(filename, 'wb') as file:
            file.write(resp.content)
        with ZipFile(filename, 'r') as myzip:
            files = myzip.namelist()
            myzip.extractall()

        for file1 in files:
            for file2 in encrypted:
                file_directory, filename = os.path.split(file1)
                if file2[0] in filename and file2[1]:
                    iv = Random.new().read(AES.block_size)
                    cipher = AES.new(sym_key, AES.MODE_ECB, iv)
                    decrypt_file(file1, file_directory+"/"+file2[0], cipher)
                elif file2[0] in filename[-len(file2[0]):]:
                    if os.path.isfile(file_directory+"/"+file2[0]):
                        os.remove(file_directory+"/"+file2[0])
                    os.rename(file1, file_directory+"/"+file2[0])
    except:
        print('Invalid list number')
    session.close()

if __name__ == '__main__':
    while True:
        print("0: encrypt file")
        print("1: decrypt file")
        print("2: download report")
        print("3: quit")
        choice = int(input('Number: '))
        if choice == 0:
            filename = input('Filename?\n')
            if os.path.isfile(filename):
                iv = Random.new().read(AES.block_size)
                cipher = AES.new(sym_key, AES.MODE_ECB, iv)
                encrypt_file(filename, cipher)
        elif choice == 1:
            filename = input('Filename?\n')
            if os.path.isfile(filename):
                iv = Random.new().read(AES.block_size)
                cipher = AES.new(sym_key, AES.MODE_ECB, iv)
                decrypt_file(filename, "DEC."+filename, cipher)
        elif choice == 2:
            download()
        elif choice == 3:
            exit(0)
        else:
            print("Invalid command")

    # connection.close()
    # if True:
        # exit(0)

# from getpass import getpass
# from secureshare import settings as s
# from django.conf import settings
# from helpers import *
#
# if __name__ == '__main__':
#     settings.configure(DATABASES=s.DATABASES, INSTALLED_APPS=s.INSTALLED_APPS)
#
#     import django
#     django.setup()
#
#     from django.db import models
#     from django.contrib.auth.models import User
#     from user.models import *
#     from django.contrib.auth import authenticate
#
#     username = str(input('Username: '))
#     password = getpass('Password: ')
#
#     user = authenticate(username=username, password=password)
#
#     if user is None:
#         print('Invalid login credentials')
#         exit(0)
#     else:
#         print('Welcome {0}\n'.format(user.username))
#
#     report_list = user.report_set.all()
#
#     i = 1
#     if len(report_list) == 0:
#         print("You have no reports.\n")
#         exit(0)
#     print('Below is a list of your reports:')
#     for report in report_list:
#         print('{0}: {1}'.format(i, report.name))
#         i += 1
#
#     print('\nTo download a report, enter the number of the report in the list: ')
#     report_index = int(input('Number: '))
#
#     # try:
#     report = report_list[report_index-1]
#     download_report(report)
#     # except:
#     #     print('Invalid list number')
