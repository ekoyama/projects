import tkinter as tk
from tkinter import filedialog, Checkbutton, IntVar
from Crypto import Random
from Crypto.Cipher import AES
from Crypto.Hash import SHA
from zipfile import ZipFile
import requests
import os

user = None
#URL = "http://127.0.0.1:8000"

URL = "http://secret-dawn-5277.herokuapp.com"

sym_key = "1234567812345678"

def encrypt_file(file_name, symmetric_key):
    chunks = []
    with open(file_name, 'rb') as in_file:
        while True:
            chunk = in_file.read(8192)
            if len(chunk) == 0:
                break
            elif len(chunk) % 16 != 0:
                chunk += ' '.encode() * (16 - len(chunk) % 16)
            chunks.append(chunk)

    with open(file_name, 'wb') as out_file:
        for chunk in chunks:
            out_file.write(symmetric_key.encrypt(chunk))
    return True

def decrypt_file(file_name, symmetric_key):
    chunks = []
    with open(file_name, 'rb') as in_file:
        while True:
            chunk = in_file.read(8192)
            if len(chunk) == 0:
                break
            chunks.append(chunk)

    with open(file_name, 'wb') as out_file:
        for chunk in chunks:
            out_file.write(symmetric_key.decrypt(chunk))
    return True

def signIn(parent):
    top = tk.Toplevel(parent)
    top.geometry('250x200')
    top.title("Sign in")
    top.grab_set()
    userMsg = tk.Label(top, text="Username")
    userMsg.pack()
    username = tk.Entry(top)
    username.pack()
    username.delete(0, tk.END)
    passMsg = tk.Label(top, text="Password")
    passMsg.pack()
    password = tk.Entry(top, font=("Wingdings"))
    password.pack()
    password.delete(0, tk.END)
    button = tk.Button(top, text="Submit", command= lambda: authenticate(parent, top, username, password))
    button.pack()

def authenticate(parent, top, username, password):
    u = username.get()
    p = password.get()
    parent.setSession(login(u, p))
    if parent.getSession():
        frames = parent.getFrames()
        frames[ReportPage].update()
        top.destroy()
        top.grab_release()
        parent.show_frame(ReportPage)
    else:
        frames = parent.getFrames()
        frames[ReportPage].update2()

def login(username, password):
    session = requests.Session()
    resp = session.get(URL)
    cookie = resp.headers['Set-Cookie']
    csrf = cookie.split(';')[0].split('=')[1].encode()
    data = {'username': username, 'password': password, 'csrfmiddlewaretoken':csrf}
    resp = session.post(URL, data=data)
    if 'homepage' in resp.url:
        return session
    return None

def getReports(session):
    resp = session.get(URL+"/homepage/2", stream=True)
    data = resp.text.split('\n')
    myReports = {}
    sharedReports = {}
    publicReports = {}
    fieldTag = "<input type=hidden"
    descriptionTag = "<input type=hidden name=description value="
    nameTag = "value="
    for i in range(len(data)):
        line = data[i].strip()
        if fieldTag == line[:len(fieldTag)] and descriptionTag != line[:len(descriptionTag)]:
            fields = line.split()
            description = data[i+1].strip()[len(descriptionTag)+1:len(data[i+1].strip())-2]
            params = fields[2].split('_')[1:]
            index = line.find(nameTag)
            rfname = line[index+len(nameTag)+1:len(line)-2]
            if params[0] == 'report':
                if params[1] == 'mine':
                    myReports[params[2]] = (rfname, [], description)
                if params[1] == 'shared':
                    sharedReports[params[2]] = (rfname, [], description)
            if params[0] == 'file':
                if params[1] in myReports:
                    (name, files, description) = myReports[params[1]]
                    if params[2] == "True":
                        files.append((rfname, True))
                    else:
                        files.append((rfname, False))
                    myReports[params[1]] = (name, files, description)
                if params[1] in sharedReports:
                    (name, files, description) = sharedReports[params[1]]
                    if params[2] == "True":
                        files.append((rfname, True))
                    else:
                        files.append((rfname, False))
                    sharedReports[params[1]] = (name, files, description)
    return (myReports, sharedReports, publicReports)

def downloadReport(session, pk, report):
    reportFiles = report[1]
    resp = session.get(URL+'/download/'+str(pk), stream=True)
    header = resp.headers['content-disposition']
    index = header.find("filename=")
    zipfile = header[index+9:]
    with open(zipfile, 'wb') as file:
        file.write(resp.content)
    with ZipFile(zipfile, 'r') as myzip:
        files = myzip.namelist()
        myzip.extractall()

    for file1 in files:
        for file2 in reportFiles:
            file_directory, filename = os.path.split(file1)
            if file2[0] in filename[-len(file2[0]):]:
                if os.path.isfile(file_directory+"/"+file2[0]):
                     os.remove(file_directory+"/"+file2[0])
                os.rename(file1, file_directory+"/"+file2[0])
    # for file1 in files:
    #     for file2 in encrypted:
    #         file_directory, filename = os.path.split(file1)
    #         if file2[0] in filename and file2[1]:
    #             iv = Random.new().read(AES.block_size)
    #             cipher = AES.new(sym_key, AES.MODE_ECB, iv)
    #             decrypt_file(file1, file_directory+"/"+file2[0], cipher)
    #         elif file2[0] in filename[-len(file2[0]):]:
    #             if os.path.isfile(file_directory+"/"+file2[0]):
    #                 os.remove(file_directory+"/"+file2[0])
    #             os.rename(file1, file_directory+"/"+file2[0])
    os.remove(zipfile)

class FDAGUI(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        self.session = None
        for F in (MainPage, EncryptPage, DecryptPage, ReportPage):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")
        self.show_frame(MainPage)

    def getSession(self):
        return self.session

    def setSession(self, session):
        self.session = session

    def getFrames(self):
        return self.frames

    def show_frame(self, c):
        frame = self.frames[c]

        if frame.__class__.__name__ == "ReportPage" and not self.session:
            signIn(self)
            if self.session:
                frame.update()
                frame.tkraise()
        if self.session or not frame.__class__.__name__ == "ReportPage" :
            frame.tkraise()

class MainPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="MainPage")
        label.pack(side="top", fill="x", pady=10)

        encryptButton = tk.Button(self, text="Encrypyt Files",
                            command=lambda: controller.show_frame(EncryptPage))
        decryptButton = tk.Button(self, text="Decrypt Files",
                            command=lambda: controller.show_frame(DecryptPage))
        reportsButton = tk.Button(self, text="View Reports",
                            command=lambda: controller.show_frame(ReportPage))
        encryptButton.pack()
        decryptButton.pack()
        reportsButton.pack()

class EncryptPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="Encrypt")
        label.pack(side="top", fill="x", pady=10)

        label = tk.Label(self, text="Please type key before choosing files")
        label.pack(side="top", fill="x", pady=10)

        key = tk.Entry(self)
        keyLabel = tk.Label(self, text="Key")
        keyLabel.pack()
        key.pack()

        files = tk.Button(self, text="Files", command=lambda: self.encryptFiles(key))
        files.pack()

        button = tk.Button(self, text="Back",
                           command=lambda: controller.show_frame(MainPage))
        button.pack()

    def encryptFiles(self, key):
        k = key.get()
        h = SHA.new()
        h.update(k.encode())
        k = h.hexdigest()[:16]
        files = filedialog.askopenfilenames()
        for file in files:
            iv = Random.new().read(AES.block_size)
            cipher = AES.new(k, AES.MODE_ECB, iv)
            encrypt_file(file, cipher)

class DecryptPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="Decrypt")
        label.pack(side="top", fill="x", pady=10)

        label = tk.Label(self, text="Please type key before choosing files")
        label.pack(side="top", fill="x", pady=10)

        key = tk.Entry(self, text="Key")
        keyLabel = tk.Label(self, text="Key")
        keyLabel.pack()
        key.pack()

        files = tk.Button(self, text="Files", command=lambda: self.decryptFiles(key))
        files.pack()

        button = tk.Button(self, text="Back",
                           command=lambda: controller.show_frame(MainPage))
        button.pack()

    def decryptFiles(self, key):
        k = key.get()
        h = SHA.new()
        h.update(k.encode())
        k = h.hexdigest()[:16]
        files = filedialog.askopenfilenames()
        for file in files:
            iv = Random.new().read(AES.block_size)
            cipher = AES.new(k, AES.MODE_ECB, iv)
            decrypt_file(file, cipher)

class ReportPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

    def update(self):
        label = tk.Label(self, text="Reports")
        label.pack(side="top", fill="x", pady=10)
        session = self.controller.getSession()
        if session:
            r = {}
            reports = getReports(self.controller.getSession())
            if (len(reports[0])+len(reports[1])+len(reports[2])) == 0:
                label = tk.Label(self, text="No reports available")
                label.pack()
            else:
                checkButtons = []
                if len(reports[0]) > 0:
                    label = tk.Label(self, text="My Reports")
                    label.pack(side="top", fill="x", pady=10)
                    for pk in reports[0]:
                        v = IntVar()
                        checkButton = Checkbutton(self, text=reports[0][pk][0], variable=v, onvalue=pk, offvalue=-1)
                        checkButton.var = v
                        checkButton.pack()
                        checkButtons.append(checkButton)
                        message = tk.Message(self, text=reports[0][pk][2], width=50)
                        message.pack()
                        r[int(pk)] = reports[0][pk]
                if len(reports[1]) > 0:
                    label = tk.Label(self, text="Shared Reports")
                    label.pack(side="top", fill="x", pady=10)
                    for pk in reports[1]:
                        v = IntVar()
                        checkButton = tk.Checkbutton(self, text=reports[1][pk][0], variable=v, onvalue=pk, offvalue=-1)
                        checkButton.var = v
                        checkButton.pack()
                        checkButtons.append(checkButton)
                        message = tk.Message(self, text=reports[1][pk][2], width=50)
                        message.pack()
                        r[int(pk)] = reports[1][pk]

                download = tk.Button(self, text="download",
                           command=lambda: self.download(checkButtons, r))
                download.pack()
        button = tk.Button(self, text="Back",
                           command=lambda: self.controller.show_frame(MainPage))
        button.pack()

    def update2(self):
        widgets = self.winfo_children()
        for widget in widgets:
            widget.destroy()

    def download(self, buttons, reports):
        for button in buttons:
            pk = button.var.get()
            if pk in reports:
                downloadReport(self.controller.getSession(), pk, reports[pk])

if __name__ == '__main__':
    master = FDAGUI()
    master.geometry('500x500')
    master.mainloop()