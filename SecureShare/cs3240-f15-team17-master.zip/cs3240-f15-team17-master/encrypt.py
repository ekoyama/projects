__author__ = 'jcs6pb'


from Crypto.PublicKey import RSA
from Crypto.Cipher import AES
from Crypto import Random



def encrypt(word, key):
    return key.encrypt(word.encode(), 32)[0]

def decrypt(encrypted, key):
    return key.decrypt(encrypted)

def encrypt_file(file_name, symmetric_key):
    encrypted = False

    with open(file_name, 'rb') as in_file:
        with open('{0}.enc'.format(file_name), 'wb') as out_file:
            while True:
                chunk = in_file.read(8192)

                if len(chunk) == 0:
                    break
                elif len(chunk) % 16 != 0:
                    chunk += ' '.encode() * (16 - len(chunk) % 16)

                out_file.write(symmetric_key.encrypt(chunk))

        encrypted = True

    return encrypted

def decrypt_file(file_name, symmetric_key):
    decrypted = False

    with open(file_name, 'rb') as in_file:
        with open('DEC_{0}'.format(file_name.replace('.enc', '')), 'wb') as out_file:
            while True:
                chunk = in_file.read(8192)

                if len(chunk) == 0:
                    break

                out_file.write(symmetric_key.decrypt(chunk))

        decrypted = True

    return decrypted

if __name__ == '__main__':
    random_generator = Random.new().read
    key = RSA.generate(1024, random_generator)
    print(key)
    # test = encrypt('test', key)
    # print(test)
    # print()
    # decrypted = test.decode('utf-8', errors='replace')
    # print(decrypted)
    # print()
    # enc = decrypted.encode()
    # print(enc)
    #
    # decrypt = decrypt(test, key)
    # print(decrypt)