from zipfile import ZipFile
from io import BytesIO
import os

def download_report(report):
    byte_stream = BytesIO()
    zip_file = ZipFile(byte_stream, 'w')

    zip_sub_directory = report.name
    zip_filename = '{0}.zip'.format(zip_sub_directory)

    for file in report.report_file_set.all():
        file_directory, filename = os.path.split(file.file.path)
        zip_path = os.path.join(zip_sub_directory, filename)
        zip_file.write(file.file.path, zip_path)

    zip_file.close()
