from user.models import User_Profile
from django.utils import timezone


class UpdateLastActivityMiddleware(object):
    def process_view(self, request, view_func, view_args, view_kwargs):
        assert hasattr(request, 'user')
        if request.user.is_authenticated():
            User_Profile.objects.filter(user__id=request.user.pk).update(last_activity=timezone.now())
