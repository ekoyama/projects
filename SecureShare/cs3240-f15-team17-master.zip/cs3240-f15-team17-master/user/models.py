from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.validators import MinValueValidator, MaxValueValidator


def user_directory_path(instance, filename):
    return '{0}/{1}/{2}_{3}'.format(instance.report.creator.pk, instance.report.pk, instance.pk, filename)

class User_Profile(models.Model):
    user = models.OneToOneField(User)
    invalid_login_attempts = models.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(3)], default=0)
    last_activity = models.DateTimeField(default=timezone.now())
    logged_in = models.BooleanField(default=False)
    public_key = models.CharField(max_length=1000, null=True)

class Password_Reset(models.Model):
    user = models.OneToOneField(User)
    token = models.CharField(max_length=50)

class Report(models.Model):
    creator = models.ForeignKey(User)
    create_timestamp = models.DateTimeField(default=timezone.now())
    name = models.CharField(max_length=50, null=True)
    long_description = models.CharField(max_length=150, null=True)
    private = models.BooleanField(default=False)

class Report_File(models.Model):
    report = models.ForeignKey(Report)
    file = models.FileField(upload_to=user_directory_path, null=True, blank=True)
    name = models.CharField(max_length=255, null=True)
    encrypted = models.BooleanField(default=False)

class Message(models.Model):
    sender = models.ForeignKey(User, related_name='sender')
    recipient = models.ForeignKey(User, related_name='recipient')
    create_timestamp = models.DateTimeField(default=timezone.now())
    subject = models.CharField(max_length=40, null=True)
    content = models.CharField(max_length=500, null=True)
    encrypted = models.BooleanField(default=False)
    decrypted = models.BooleanField(default=False)
    read = models.BooleanField(default=False)

class Group(models.Model):
    creator = models.ForeignKey(User)
    create_timestamp = models.DateTimeField(default=timezone.now())
    name = models.CharField(max_length=80, null=False)

class Group_Relations(models.Model):
    group = models.ForeignKey(Group)
    user = models.ForeignKey(User)

class Group_Report_Relation(models.Model):
    group = models.ForeignKey(Group)
    report = models.ForeignKey(Report)
    user = models.ForeignKey(User)

class Folder(models.Model):
    creator = models.ForeignKey(User)
    create_timestamp = models.DateTimeField(default=timezone.now())
    name = models.CharField(max_length=80, null=False)

class Folder_Report(models.Model):
    folder = models.ForeignKey(Folder)
    report = models.ForeignKey(Report)

class Friend(models.Model):
    user = models.ForeignKey(User, related_name='user')
    friend = models.ForeignKey(User, related_name='friend')
    requested = models.BooleanField(default=False)
    approved = models.BooleanField(default=False)