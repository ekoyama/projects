from django.forms import ModelForm
from django import forms
from user.models import *

class UserForm(ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'is_superuser', 'is_active']

    def __init__(self, *args, **kwargs):
        super(UserForm, self).__init__(*args, **kwargs)
        self.fields['first_name'].widget.attrs.update({'class' : 'form-control', 'required' : 'true'})
        self.fields['last_name'].widget.attrs.update({'class' : 'form-control', 'required' : 'true'})
        self.fields['email'].widget.attrs.update({'class' : 'form-control', 'required' : 'true'})

class ReportForm(ModelForm):
    class Meta:
        model = Report
        fields = ['name', 'long_description', 'private']
        widgets = {'long_description': forms.Textarea }

    def __init__(self, *args, **kwargs):
        super(ReportForm, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({'class' : 'form-control', 'required' : 'true'})
        self.fields['long_description'].widget.attrs.update({'class' : 'form-control', 'rows': '4', 'cols' : '5', 'required' : 'true'})

class MessageForm(ModelForm):
    class Meta:
        model = Message
        fields = ['recipient', 'subject', 'content', 'encrypted']
        widgets = {'content': forms.Textarea}

    def __init__(self, *args, **kwargs):
        super(MessageForm, self).__init__(*args, **kwargs)
        self.fields['recipient'].widget.attrs.update({'class' : 'form-control', 'required' : 'true'})
        self.fields['subject'].widget.attrs.update({'class': 'form-control', 'required' : 'true'})
        self.fields['content'].widget.attrs.update({'class' : 'form-control', 'rows': '10', 'cols' : '10', 'required' : 'true', 'placeholder': 'Type message here'})

class GroupForm(ModelForm):

    users = forms.ModelChoiceField(queryset=User.objects.all())

    class Meta:
        model = Group
        fields = ['name']

    def __init__(self, *args, **kwargs):
        super(GroupForm, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({'class' : 'form-control', 'required' : 'true'})
        self.fields['users'].widget.attrs.update({'class' : 'form-control', 'required' : 'true', 'multiple': 'true'})
        self.fields['users'].label_from_instance = lambda obj: "{0}, {1}".format(obj.last_name, obj.first_name)
