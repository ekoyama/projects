var text_counter = 1;
var text_limit = 30;
function addInput(divName){
  if (text_counter==text_limit) {
    alert("You have reached the limit of adding " + counter + " users");
  }
  else {
    var newDiv = document.createElement('div');
    newDiv.className = "form-group col-sm-4 col-sm-offset-4";
    var currentUser = "user" + (text_counter + 1);
    newDiv.innerHTML = "<input type='text' class='form-control' name='" + currentUser + "'>";
    document.getElementById(divName).appendChild(newDiv);
    text_counter++;
  }
}

var file_counter = 1;
var file_limit = 30;
function addFile(divName){
  if (file_counter==file_limit) {
    alert("You have reached the limit of adding " + file_counter + " files");
  }
  else {
    var newDiv = document.createElement('div');
    newDiv.className = "form-group col-sm-4 col-sm-offset-4";

    var newDiv2 = document.createElement('div');
    newDiv2.className = "row";

    newDiv.appendChild(newDiv2);

    var newDiv3 = document.createElement('div');
    newDiv3.className = "col-sm-6";

    var newDiv4 = document.createElement('div');
    newDiv4.className = "col-sm-6 file-checkbox";

    var currentFile = "file" + (file_counter + 1);
    var currentCheckbox = "file" + (file_counter + 1) + "checkbox";
    newDiv3.innerHTML = "<input type='file' name='" + currentFile + "'>";
    newDiv4.innerHTML = "<input type='checkbox' name='"+ currentCheckbox + "'>";

    newDiv2.appendChild(newDiv3);
    newDiv2.appendChild(newDiv4);

    document.getElementById(divName).appendChild(newDiv);
    file_counter++;
  }
}
