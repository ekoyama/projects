from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.models import User
from .forms import *
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import *
from django.core.urlresolvers import reverse
from django.core.exceptions import ObjectDoesNotExist, PermissionDenied
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.template.loader import render_to_string
from user.models import *
from django.contrib.sites.models import get_current_site
from django.core.files import File
from django.core.mail import send_mail
from django.utils.crypto import get_random_string
from django.utils.encoding import *
import pdb
from django.utils import timezone
from django.conf import settings
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES
from encrypt import *
from zipfile import ZipFile
from io import BytesIO
import os, shutil
import base64


def log_in(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        try:
            user = authenticate(username=username, password=password)

            if user.is_superuser:
                if user is not None:
                    try:
                        User_Profile.objects.get(user=user)
                    except:
                        key = RSA.generate(2048)
                        public_key = key.publickey().exportKey()

                        user_profile = User_Profile.objects.create(user=user, invalid_login_attempts=0, public_key=public_key)
                        user_profile.save()

                        subject = 'Your New Account and Private Key'
                        content = render_to_string('user/key_email.html', {'key': key.exportKey()})

                        send_mail(subject, content, 'secureshare@gmail.com', [user.email], html_message=content)

                    login(request, user)
                    return redirect('user:homepage', active_tab=1)
                else:
                    messages.add_message(request, messages.INFO, 'Invalid login attempt')
            else:
                user_profile = user.user_profile

                if user.is_active:
                    user_profile.invalid_login_attempts = 0
                    user_profile.logged_in = True
                    user_profile.save()
                    login(request, user)
                    return redirect('user:homepage', active_tab=1)
                else:
                    messages.add_message(request, messages.INFO,
                                         'Invalid login attempt. This username has been suspended. Please contact your systems administrator.')
        except:
            try:
                user = User.objects.get(username=username)
                user_profile = user.user_profile

                if user_profile.invalid_login_attempts < 3:
                    user_profile.invalid_login_attempts += 1
                    user_profile.save()

                    if user_profile.invalid_login_attempts == 3:
                        user.is_active = False
                        user.save()
                        messages.add_message(request, messages.INFO,
                                             'Invalid login attempt. This username has been suspended. Please contact your systems administrator.')
                    else:
                        messages.add_message(request, messages.INFO, 'Invalid login attempt')
                else:
                    messages.add_message(request, messages.INFO,
                                         'Invalid login attempt. This username has been suspended. Please contact your systems administrator.')
            except:
                messages.add_message(request, messages.INFO, 'Invalid login attempt')

    return render(request, 'user/login.html')


def log_out(request):
    user_profile = request.user.user_profile
    user_profile.logged_in = False
    user_profile.save()

    logout(request)

    return redirect('user:login')


def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        email = request.POST.get('email_address')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')

        if password != confirm_password:
            messages.add_message(request, messages.INFO, 'Passwords do not match')
            return render(request, 'user/register.html')
        if len(password) < 8 or len(password) > 15:
            messages.add_message(request, messages.INFO, 'Password must be between 8 and 15 characters')
            return render(request, 'user/register.html')
        try:
            User.objects.get(username=username)
            messages.add_message(request, messages.INFO, 'The username already exists')
        except:
            try:
                User.objects.get(email=email)
                messages.add_message(request, messages.INFO, 'The email address is associated to an existing account')
            except:
                user = User.objects.create_user(username=username, email=email, password=password,
                                                first_name=first_name, last_name=last_name)
                user.is_active = True
                user.save()

                key = RSA.generate(2048)
                public_key = key.publickey().exportKey()

                user_profile = User_Profile.objects.create(user=user, invalid_login_attempts=0, public_key=public_key)
                user_profile.save()

                subject = 'Your New Account and Private Key'
                content = render_to_string('user/key_email.html', {'key': key.exportKey()})

                send_mail(subject, content, 'secureshare@gmail.com', [email], html_message=content)

                return redirect('user:login')

    return render(request, 'user/register.html')


def public(request):
    reports = Report.objects.filter(private=False)
    return render(request, 'user/public.html', {'reports': reports})


@login_required()
def homepage(request, active_tab):
    user = request.user
    owned_groups = user.group_set.all()
    other_groups = user.group_relations_set.all()
    folders = user.folder_set.all()

    request.session['messages'] = len(user.recipient.filter(read=False)) + len(user.user.filter(requested=False, approved=False))

    context = {}
    group_list = []

    for group in owned_groups:
        group_list.append(group)

    for relation in other_groups:
        if relation.group.creator != user:
            group_list.append(relation.group)

    shared = []
    for group in Group.objects.all():
        if user == group.creator:
            continue
        members = group.group_relations_set.filter(user=user)
        for member in members:
            if member.user == user:
                for report in group.group_report_relation_set.all():
                    shared.append(report.report)
    folder_list = []
    for folder in folders:
        report_list = []
        for relation in folder.folder_report_set.all():
            report_list.append(relation.report.pk)

        folder_list.append({'folder': folder, 'folder_reports': user.report_set.exclude(id__in=report_list)})

    context['user'] = user
    context['groups'] = group_list
    context['myReports'] = user.report_set.all().order_by('name')
    context['sharedReports'] = shared
    context['folders'] = folder_list
    context['active_tab'] = int(active_tab)

    return render(request, 'user/homepage.html', context)


@login_required()
def create_report(request):
    if request.method == 'POST':
        form = ReportForm(request.POST, request.FILES)
        if form.is_valid():
            user = request.user
            name = form.cleaned_data['name']
            long_description = form.cleaned_data['long_description']
            is_private = form.cleaned_data['private']

            try:
                Report.objects.get(creator=user, name=name)
                messages.add_message(request, messages.INFO, 'You already have a report with that name')
                return render(request, 'user/create_report.html', {'form': form})
            except:
                report = Report.objects.create(creator=user, name=name, long_description=long_description,
                                               private=is_private)
                report.save()

                input_num = 1
                while request.FILES.get('file{0}'.format(str(input_num))):
                    file = request.FILES.get('file{0}'.format(str(input_num)))

                    if request.POST.get('file{0}checkbox'.format(str(input_num))) is not None:
                        new_file = Report_File.objects.create(report=report, encrypted=True, name=file.name)
                    else:
                        new_file = Report_File.objects.create(report=report, encrypted=False, name=file.name)
                    new_file.file = file
                    new_file.save()
                    input_num += 1

        return redirect('user:homepage', active_tab=2)

    else:
        form = ReportForm()

    return render(request, 'user/create_report.html', {'form': form})


@login_required()
def edit_report(request, report_pk, file_pk=None):
    report = Report.objects.get(pk=report_pk)

    if not request.user.is_superuser and report.creator != request.user:
        raise PermissionDenied

    if request.method == 'POST':
        form = ReportForm(request.POST, request.FILES)

        if form.is_valid():
            user = request.user
            report.name = form.cleaned_data['name']
            report.long_description = form.cleaned_data['long_description']
            report.private = form.cleaned_data['private']
            report.save()

            input_num = 2
            while request.FILES.get('file{0}'.format(str(input_num))):
                file = request.FILES.get('file{0}'.format(str(input_num)))

                if request.POST.get('file{0}checkbox'.format(str(input_num))) is not None:
                    new_file = Report_File.objects.create(report=report, encrypted=True, name=file.name)
                else:
                    new_file = Report_File.objects.create(report=report, encrypted=False, name=file.name)
                new_file.file = file
                new_file.save()
                input_num += 1

        return redirect('user:homepage', active_tab=2)
    else:
        if file_pk:
            file = Report_File.objects.get(pk=file_pk)
            file.delete()
            # os.remove('files'/+file)

        report_files = report.report_file_set.all()
        encrypted = False
        for file in report_files:
            encrypted = file.encrypted
        form = ReportForm(
            initial={'name': report.name, 'long_description': report.long_description,
                     'private': report.private, 'encrypted': encrypted})

    return render(request, 'user/edit_report.html', {'form': form, 'report_pk': report_pk, 'files': report_files})


@login_required()
def delete_report(request, report_pk):
    try:
        report = Report.objects.get(pk=report_pk)
        if report.creator != request.user:
            raise PermissionDenied
        report.delete()
        shutil.rmtree('files/' + str(request.user.pk) + '/' + str(report_pk) + '/')
    except:
        pass
    return redirect('user:homepage', active_tab=1)


def download_report(request, report_pk):
    report = get_object_or_404(Report, pk=report_pk)
    files = Report_File.objects.filter(report=report_pk)
    b = BytesIO()
    zip_file = ZipFile(b, 'w')

    zip_subdir = report.name
    zip_filename = '{0}.zip'.format(zip_subdir)

    for file in files:
        file_directory, filename = os.path.split(file.file.path)
        zip_path = os.path.join(zip_subdir, filename)
        try:
            zip_file.write(file.file.path, zip_path)
        except:
            continue

    zip_file.close()

    response = HttpResponse(b.getvalue(), content_type='application/zip')
    response['Content-Disposition'] = 'attachment; filename={0}'.format(zip_filename)
    return response


@login_required()
def create_message(request, recipient_pk=None, message_pk=None):
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            sender = request.user
            recipient = form.cleaned_data['recipient']
            subject = form.cleaned_data['subject']
            content = form.cleaned_data['content']
            encrypted = form.cleaned_data['encrypted']

            if encrypted:
                public_key = RSA.importKey(recipient.user_profile.public_key)
                content = base64.b64encode(encrypt(content, public_key))

            message = Message.objects.create(sender=sender, recipient=recipient, create_timestamp=timezone.now(),
                                             subject=subject, content=content, encrypted=encrypted)
            message.save()

            subject = 'New Private Message'
            path = 'http://{0}/viewmessage/{1}'.format(get_current_site(request), message.pk)
            content = render_to_string('user/message_email.html', {'path': path, 'from': message.sender.username})

            send_mail(subject, content, 'secureshare@gmail.com', [message.recipient.email], html_message=content)

        return redirect('user:message_list', active_tab=1)

    if message_pk:
        message = Message.objects.get(pk=message_pk)
        form = MessageForm(initial={'recipient': message.sender, 'subject': 'RE: {0}'.format(message.subject)})
    elif recipient_pk:
        recipient = User.objects.get(pk=recipient_pk)
        form = MessageForm(initial={'recipient': recipient})
    else:
        form = MessageForm()

    return render(request, 'user/create_message.html', {'form': form})


@login_required()
def message_list(request, active_tab):
    user = request.user

    request.session['friends'] = len(user.user.all().filter(requested=False, approved=False))

    context = {}
    friend_list = []

    for friendship in user.user.all():
        last_active = (timezone.now() - friendship.friend.user_profile.last_activity).seconds / 60
        friend_list.append({'friendship': friendship, 'last_active': last_active})

    context['messages'] = user.recipient.all().order_by('-create_timestamp')
    context['friends'] = friend_list
    context['active_tab'] = int(active_tab)
    context['current_time'] = timezone.now()

    return render(request, 'user/message_list.html', context)


@login_required()
def view_message(request, message_pk):
    message = Message.objects.get(pk=message_pk)

    if message.recipient != request.user:
        raise PermissionDenied

    if message.read is False:
        message.read = True
        message.save()
        request.session['messages'] -= 1

    context = {}
    context['message'] = message
    context['sender'] = '{0} {1}'.format(message.sender.first_name, message.sender.last_name)
    context['date'] = message.create_timestamp
    context['subject'] = message.subject
    context['content'] = message.content
    context['encrypted'] = message.encrypted
    context['decrypted'] = message.decrypted

    return render(request, 'user/view_message.html', context)


@login_required()
def decrypt_message(request, message_pk):
    user = request.user
    message = Message.objects.get(pk=message_pk)

    content = message.content
    private_key = request.POST.get('private_key')

    private_key = private_key.replace('-----BEGIN RSA PRIVATE KEY-----', '')
    private_key = private_key.replace('-----END RSA PRIVATE KEY-----', '')
    private_key = private_key.replace(' ', '\n')

    final = '-----BEGIN RSA PRIVATE KEY-----\n{0}\n-----END RSA PRIVATE KEY-----'.format(private_key)

    message.decrypted = True
    message.save()

    content = decrypt(base64.b64decode(message.content), RSA.importKey(final))

    context = {}
    context['message'] = message
    context['sender'] = '{0} {1}'.format(message.sender.first_name, message.sender.last_name)
    context['date'] = message.create_timestamp
    context['subject'] = message.subject
    context['content'] = content
    context['encrypted'] = message.encrypted
    context['decrypted'] = message.decrypted

    return render(request, 'user/view_message.html', context)


@login_required()
def delete_message(request, message_pk):
    message = Message.objects.get(pk=message_pk)

    if message.recipient != request.user:
        raise PermissionDenied

    message.delete()

    return redirect('user:message_list', active_tab=1)


@login_required()
def create_group(request):
    user = request.user

    if request.method == 'POST':
        name = request.POST.get('name')

        try:
            Group.objects.get(creator=user, name=name)
            messages.add_message(request, messages.INFO, 'A group with that name already exists')
            return render(request, 'user/create_group.html', context={'num_users': range(1, 2)})
        except:
            user_list = [user]

            i = 0
            while True:
                group_username = request.POST.get('user' + str(i + 1))
                if group_username is None:
                    break
                i += 1
                if len(group_username) > 0:
                    try:
                        group_user = User.objects.get(username=group_username)

                        if group_user == user:
                            messages.add_message(request, messages.INFO, 'You can not add yourself to the group')
                            return render(request, 'user/create_group.html', context={'num_users': range(1, 2)})

                        if group_user in user_list:
                            messages.add_message(request, messages.INFO, 'You can not add the same user to the group')
                            return render(request, 'user/create_group.html', context={'num_users': range(1, 2)})

                        user_list.append(group_user)
                    except:
                        messages.add_message(request, messages.INFO, 'The user does not exist in the system')
                        return render(request, 'user/create_group.html', context={'num_users': range(1, 2)})

            group = Group.objects.create(name=name, creator=user)

            for member in user_list:
                Group_Relations.objects.create(group=group, user=member)

                if member != user:
                    subject = 'New Group'
                    path = 'http://{0}/editgroup/{1}/1'.format(get_current_site(request), group.pk)
                    content = render_to_string('user/message_group.html',
                                               {'path': path, 'user': member, 'name': group.name})

                    send_mail(subject, content, 'secureshare@gmail.com', [member.email], html_message=content)

        return redirect('user:homepage', active_tab=1)

    return render(request, 'user/create_group.html', context={'num_users': range(1, 2)})


@login_required()
def edit_group(request, group_pk, active_tab):
    user = request.user
    username = request.POST.get('username')
    group = Group.objects.get(pk=group_pk)
    members = group.group_relations_set.all()

    if 'add' in request.POST:
        try:
            group_user = User.objects.get(username=username)
            try:
                group_relation = Group_Relations.objects.get(group=group, user=group_user)
                messages.add_message(request, messages.INFO, 'The user is already a member of the group')
            except:
                Group_Relations.objects.create(group=group, user=group_user)
        except:
            messages.add_message(request, messages.INFO, 'The user does not exist in the system')

    elif 'add_report' in request.POST:
        name = request.POST.get('report')
        report = Report.objects.get(creator=user, name=name)
        try:
            group_relation = group.group_report_relation_set.get(report=report)
            messages.add_message(request, messages.INFO, 'The report is already shared with this group')
        except:
            Group_Report_Relation.objects.create(user=user, group=group, report=report)

    added_report_list = []
    for report in group.group_report_relation_set.all():
        added_report_list.append(report.report)

    report_list = []
    for report in added_report_list:
        report_list.append(report.pk)

    reports = user.report_set.exclude(id__in=report_list).order_by('name')

    context = {'group': group, 'members': members, 'reports': reports, 'group_reports': added_report_list,
               'active_tab': int(active_tab)}

    return render(request, 'user/edit_group.html', context)


@login_required()
def remove_group_member(request, group_pk, user_pk, active_tab):
    user = request.user
    username = request.POST.get('username')
    group = get_object_or_404(Group, pk=group_pk)
    members = group.group_relations_set.all()

    try:
        group_user = User.objects.get(pk=user_pk)
        try:
            group_relation = Group_Relations.objects.get(group=group, user=group_user)
            group_relation.delete()
        except:
            messages.add_message(request, messages.INFO, 'The user is not a member of the group')
    except:
        messages.add_message(request, messages.INFO, 'The user does not exist in the system')

    added_reports = group.group_report_relation_set.all()

    added_report_list = []

    for report in added_reports:
        added_report_list.append(report.report)

    reports = user.report_set.all()
    report_list = []

    for report in reports:
        report_list.append(report)

    context = {'group': group, 'members': members, 'reports': report_list, 'added_report_list': added_report_list,
               'active_tab': int(active_tab)}

    return render(request, 'user/edit_group.html', context)


@login_required()
def remove_group_report(request, group_pk, report_pk, active_tab):
    user = request.user
    username = request.POST.get('username')
    group = Group.objects.get(pk=group_pk)
    members = group.group_relations_set.all()

    report = Report.objects.get(pk=report_pk)
    try:
        group_report_relation = group.group_report_relation_set.get(report=report)
        group_report_relation.delete()
    except:
        messages.add_message(request, messages.INFO, 'The report is not currently shared with this group')

    added_reports = group.group_report_relation_set.all()

    added_report_list = []

    for report in added_reports:
        added_report_list.append(report.report)

    reports = user.report_set.all()
    report_list = []

    for report in reports:
        report_list.append(report)

    context = {'group': group, 'members': members, 'reports': report_list, 'added_report_list': added_report_list,
               'active_tab': int(active_tab)}

    return render(request, 'user/edit_group.html', context)


@login_required()
def delete_group(request, group_pk):
    group = Group.objects.get(pk=group_pk)

    if group.creator != request.user:
        raise PermissionDenied

    group.delete()

    return redirect('user:homepage', active_tab=1)


@login_required()
def search(request):
    user = request.user

    context = {}
    report_list = []
    result = set()

    if request.method == 'POST':
        search_criteria = request.POST.get('criteria')
        search_logic = request.POST.get('boolean')
        search_list = request.POST.get('search_criteria')
        if search_list == "":
            search_list = [""]
        else:
            search_list = search_list.split()

        if user.is_superuser:
            if search_logic == 'AND':
                if search_criteria == 'Name':
                    reports = Report.objects.filter(name__icontains=search_list[0])
                    for word in search_list:
                        reports = reports.filter(name__icontains=word)
                    for x in reports:
                        result.add(x)
                else:
                    reports = Report.objects.filter(long_description__icontains=search_list[0])
                    for word in search_list:
                        reports = reports.filter(long_description__icontains=word)
                    for x in reports:
                        result.add(x)

            elif search_logic == 'OR':
                if search_criteria == 'Name':
                    for word in search_list:
                        reports = Report.objects.filter(name__icontains=word)
                        for x in reports:
                            result.add(x)
                else:
                    for word in search_list:
                        reports = Report.objects.filter(long_description__icontains=word)
                        for x in reports:
                            result.add(x)

        else:
            if search_logic == 'AND':
                if search_criteria == 'Name':
                    reports = Report.objects.filter(name__icontains=search_list[0], private=False)
                    for word in search_list:
                        reports = reports.filter(name__icontains=word)
                    for x in reports:
                        result.add(x)
                    for group in Group.objects.all():
                        members = group.group_relations_set.filter(user=user)
                        for member in members:
                            if member.user == user:
                                for report in group.group_report_relation_set.all():
                                    result.add(report.report)

                else:
                    reports = Report.objects.filter(long_description__icontains=search_list[0], private=False)
                    for word in search_list:
                        reports = reports.filter(long_description__icontains=word)
                    for x in reports:
                        result.add(x)
                    for group in Group.objects.all():
                        members = group.group_relations_set.filter(user=user)
                        for member in members:
                            if member.user == user:
                                for report in group.group_report_relation_set.all():
                                    result.add(report.report)

            elif search_logic == 'OR':
                if search_criteria == 'Name':
                    for word in search_list:
                        reports = Report.objects.filter(name__icontains=word, private=False)
                        for x in reports:
                            result.add(x)
                        for group in Group.objects.all():
                            members = group.group_relations_set.filter(user=user)
                            for member in members:
                                if member.user == user:
                                    for report in group.group_report_relation_set.all():
                                        result.add(report.report)
                else:
                    for word in search_list:
                        reports = Report.objects.filter(long_description__icontains=word, private=False)
                        for x in reports:
                            result.add(x)
                            for group in Group.objects.all():
                                members = group.group_relations_set.filter(user=user)
                                for member in members:
                                    if member.user == user:
                                        for report in group.group_report_relation_set.all():
                                            result.add(report.report)

        reports = Report.objects.filter(creator=user)
        for x in reports:
            result.add(x)

        if len(result) >= 1:
            context['reports'] = result
        else:
            messages.add_message(request, messages.INFO, 'The search criteria returned no results')

    return render(request, 'user/search.html', context)


@login_required()
def user_list(request):
    if not request.user.is_superuser:
        raise PermissionDenied

    context = {}
    user_list = []

    if request.method == 'POST':
        search_criteria = request.POST.get('search_criteria')

        users = User.objects.filter(username__contains=search_criteria).order_by('username')

        if len(users) > 0:
            for user in users:
                user_list.append(user)

            context['users'] = user_list
        else:
            messages.add_message(request, messages.INFO, 'The search criteria returned no results')

    return render(request, 'user/user_list.html', context)


@login_required()
def view_user(request, user_pk):
    if not request.user.is_superuser and request.user.pk != int(user_pk):
        raise PermissionDenied

    if request.method == 'POST':
        form = UserForm(request.POST)

        user = User.objects.get(pk=user_pk)

        if form.is_valid():
            user.first_name = form.cleaned_data['first_name']
            user.last_name = form.cleaned_data['last_name']
            user.email = form.cleaned_data['email']
            user.is_superuser = form.cleaned_data['is_superuser']

            active = form.cleaned_data['is_active']
            user.is_active = active
            user.save()

            if active:
                user_profile = user.user_profile
                user_profile.invalid_login_attempts = 0
                user_profile.save()

            return redirect('user:user_list')
    else:
        user = User.objects.get(pk=user_pk)
        form = UserForm(initial={'first_name': user.first_name,
                                 'last_name': user.last_name, 'email': user.email,
                                 'is_superuser': user.is_superuser, 'is_active': user.is_active})

    return render(request, 'user/user.html', {'form': form, 'user': user})


@login_required()
def delete_user(request, user_pk):
    if request.user.is_superuser or request.user.pk == int(user_pk):
        user = User.objects.get(pk=user_pk)
        user.delete()
    else:
        raise PermissionDenied

    if request.user.is_superuser:
        return redirect('user:user_list')

    return redirect('user:login')


@login_required()
def change_password(request):
    if request.method == 'POST':
        user = request.user

        current_password = request.POST.get('current_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        if not check_password(current_password, user.password):
            messages.add_message(request, messages.INFO, 'The current password entered is incorrect')
            return render(request, 'user/change_password.html')

        if new_password != confirm_password:
            messages.add_message(request, messages.INFO, 'Passwords do not match')
            return render(request, 'user/change_password.html')

        user.set_password(new_password)
        user.save()

        return redirect('user:homepage', active_tab=1)

    return render(request, 'user/change_password.html')


def password_reset(request):
    sent = False

    if request.method == 'POST':
        username = request.POST.get('username')

        try:
            user = User.objects.get(username=username)
            subject = 'Reset Password'
            token = get_random_string(length=24)
            path = 'http://{0}/resetpassword/{1}'.format(get_current_site(request), token)
            content = render_to_string('user/reset_email.html', {'path': path})

            send_mail(subject, content, 'secureshare@gmail.com', [user.email], html_message=content)
            sent = True

            try:
                password_reset = Password_Reset.objects.get(user=user)
                password_reset.delete()
                Password_Reset.objects.create(user=user, token=token)
            except:
                Password_Reset.objects.create(user=user, token=token)
        except:
            messages.add_message(request, messages.INFO, 'Invalid username')

    return render(request, 'user/password_reset.html', {'sent': sent})


def reset_password(request, token):
    user = None

    try:
        password_reset = Password_Reset.objects.get(token=token)
        user = password_reset.user
    except:
        messages.add_message(request, messages.INFO, 'The password reset token is no longer valid')
        return redirect('user:login')

    if request.method == 'POST':
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if password != confirm_password:
            messages.add_message(request, messages.INFO, 'Passwords do not match')
            return render(request, 'user/reset_password.html', {'token': token})

        password_reset.delete()

        user.set_password(password)
        user.save()
        user = authenticate(username=user.username, password=password)

        login(request, user)
        return redirect('user:homepage', active_tab=1)

    return render(request, 'user/reset_password.html')


@login_required()
def group_list(request):
    if not request.user.is_superuser:
        return PermissionDenied

    context = {}
    group_list = []

    if request.method == 'POST':
        search_criteria = request.POST.get('search_criteria')

        groups = Group.objects.filter(name__contains=search_criteria).order_by('name')

        if len(groups) > 0:
            for group in groups:
                group_list.append(group)

            context['groups'] = group_list
        else:
            messages.add_message(request, messages.INFO, 'The search criteria returned no results')

    return render(request, 'user/group_list.html', context)


@login_required()
def create_folder(request):
    if request.method == 'POST':
        user = request.user
        name = request.POST.get('name')

        try:
            Folder.objects.get(creator=user, name=name)
            messages.add_message(request, messages.INFO, 'You already have a folder with that name')
            return render(request, 'user/create_folder.html')
        except:
            folder = Folder.objects.create(creator=user, name=name)
            folder.save()
            return redirect('user:homepage', active_tab=3)

    return render(request, 'user/create_folder.html')


@login_required()
def edit_folder(request, folder_pk):
    folder = Folder.objects.get(pk=folder_pk)

    if folder.creator != request.user:
        raise PermissionDenied

    if request.method == 'POST':
        folder.name = request.POST.get('name')
        folder.save()

        return redirect('user:homepage', active_tab=3)

    return render(request, 'user/create_folder.html', {'edit': True, 'folder': folder})


@login_required()
def add_report(request, folder_pk):
    folder = Folder.objects.get(pk=folder_pk)

    if folder.creator != request.user:
        raise PermissionDenied

    report_pk = request.POST.get('report')
    report = Report.objects.get(pk=report_pk)

    folder_report = Folder_Report.objects.create(folder=folder, report=report)
    folder_report.save()

    return redirect('user:homepage', active_tab=3)


@login_required()
def delete_folder(request, folder_pk):
    folder = Folder.objects.get(pk=folder_pk)

    if folder.creator != request.user:
        raise PermissionDenied

    folder.delete()

    return redirect('user:homepage', active_tab=3)


@login_required()
def remove_folder_report(request, folder_pk, report_pk):
    folder = Folder.objects.get(pk=folder_pk)

    if folder.creator != request.user:
        raise PermissionDenied

    report = Report.objects.get(pk=report_pk)

    folder_report = Folder_Report.objects.get(folder=folder, report=report)
    folder_report.delete()

    return redirect('user:homepage', active_tab=3)


@login_required()
def add_friend(request):
    user = request.user

    if request.method == 'POST':
        friend_pk = request.POST.get('friend')
        friend = User.objects.get(pk=friend_pk)
        Friend.objects.create(user=user, friend=friend, requested=True, approved=False)
        Friend.objects.create(user=friend, friend=user, requested=False, approved=False)

        subject = 'New Friend Request'
        path = 'http://{0}/messagelist/2'.format(get_current_site(request))
        content = render_to_string('user/request_email.html', {'requestor': user, 'path': path})

        send_mail(subject, content, 'secureshare@gmail.com', [friend.email], html_message=content)

        return redirect('user:message_list', active_tab=2)

    friend_list = [user.pk]
    for friendship in user.user.all():
        friend_list.append(friendship.friend.pk)

    user_list = []
    for user in User.objects.exclude(id__in=friend_list).order_by('username'):
        user_list.append(user)

    return render(request, 'user/add_friend.html', {'users': user_list})


@login_required()
def approve_friend(request, friend_pk):
    user = request.user
    friend = User.objects.get(pk=friend_pk)

    Friend.objects.filter(user=user, friend=friend).update(approved=True)
    Friend.objects.filter(user=friend, friend=user).update(approved=True)

    request.session['friends'] -= 1
    request.session['messages'] -= 1

    subject = 'Friend Request Approved'
    path = 'http://{0}/friendpage/{1}'.format(get_current_site(request), user.pk)
    content = render_to_string('user/approved_email.html', {'approver': user, 'path': path})

    send_mail(subject, content, 'secureshare@gmail.com', [friend.email], html_message=content)

    return redirect('user:message_list', active_tab=2)


@login_required()
def delete_friend(request, friend_pk, deny=None):
    user = request.user
    friend = User.objects.get(pk=friend_pk)
    friendship1 = Friend.objects.get(user=user, friend=friend)
    friendship2 = Friend.objects.get(user=friend, friend=user)

    if friendship1.user != request.user:
        raise PermissionDenied

    if deny:
        request.session['messages'] -= 1

    friendship1.delete()
    friendship2.delete()

    return redirect('user:message_list', active_tab=2)


@login_required()
def view_friend(request, friend_pk, active_tab):
    user = request.user
    friend = User.objects.get(pk=friend_pk)

    friendship = Friend.objects.get(user=user, friend=friend)

    group_list = []
    for relation1 in friend.group_relations_set.all():
        shared = False
        for relation2 in user.group_relations_set.all():
            if relation1.group == relation2.group:
                group_list.append({'group': relation1.group, 'shared': True})
                shared = True
                break
        if not shared:
            group_list.append({'group': relation1.group, 'shared': False})

    mutual_friend_list = []
    for friendship1 in user.user.all():
        for friendship2 in friend.user.all():
            if friendship1.friend == friendship2.friend:
                mutual_friend_list.append(friendship1.friend)

    context = {}
    context['friend'] = friend
    context['active_tab'] = int(active_tab)
    context['groups'] = group_list
    context['reports'] = friend.report_set.filter(private=False)
    context['mutual_friends'] = mutual_friend_list
    context['num_mutual'] = len(mutual_friend_list)
    context['last_active'] = (timezone.now() - friend.user_profile.last_activity).seconds / 60

    return render(request, 'user/view_friend.html', context)

