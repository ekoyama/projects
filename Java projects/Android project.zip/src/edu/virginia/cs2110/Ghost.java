package edu.virginia.cs2110;

//import android.support.v7.app.ActionBarActivity;
//import android.support.v7.app.ActionBar;
//import android.support.v4.app.Fragment;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import javax.microedition.khronos.opengles.GL10;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;

public class Ghost extends Character {
    private int ai, speed, moveTimer, attackTimer;
	protected boolean isMoving, isAttacking;
	protected float targetX, targetY;
	protected double targetDistance, targetAngle;

	public Ghost(Resources res, Bitmap b, int x, int y, float w, float h, int ai, int s) {
		super(res, b, x, y, w, h);
		
	    speed = s;
	    moveTimer = 0;
	    attackTimer = 0;
		isMoving = false;
		isAttacking = false;
		
		this.ai = ai;
	}

	public void move(GL10 gl, Hero he) {
		float dx = 0f;
		float dy = 0f;
		float x = he.getxPosition();
		float y = he.getyPosition();
		//Log.d("hero position", x + " " + y);

		gl.glPushMatrix();
		if (xPosition - x > 5) {
			dx = -speed;
		}
		else if (x - xPosition > 5) {
			dx = speed;
		}
		if (yPosition - y > 5) {
			dy = -speed;
		}
		else if (y - yPosition > 5) {
			dy = speed;
		}
		//Log.d("Previous", xPosition + " " + yPosition);   2*(xPosition-rootX)/w
		xPosition = xPosition + dx;
		yPosition = yPosition + dy;
		//Log.d("Next", xPosition + " " + yPosition);
		gl.glTranslatef(2*(xPosition-rootX)/w, 2*(yPosition-rootY)/h, 0f);	
		draw(gl);
		gl.glPopMatrix();
		
	}
	
	
	public void draw(GL10 gl) {
		super.draw(gl);
	}
	
/*
	public void draw(Canvas c, int x, int y, int time, int w, int h) {
		super.draw(c);
		//move(x,y,time, w, h);
		c.drawBitmap(bit, xPosition, yPosition, new Paint());
	}
	
			vertices = new float[] {
				2*(x-width/2-w/2)/w, 2*(y-height/2-h/2)/h, 0f,
				2*(x-width/2-w/2)/w, 2*(y+height/2-h/2)/h, 0f,
				2*(x+width/2-w/2)/w, 2*(y-height/2-h/2)/h, 0f,
				2*(x+width/2-w/2)/w, 2*(y+height/2-h/2)/h, 0f
		};
		ByteBuffer BB = ByteBuffer.allocateDirect(vertices.length*4);
		BB.order(ByteOrder.nativeOrder());
		vertexB = BB.asFloatBuffer();
		vertexB.put(vertices);
		vertexB.position(0);
		
		BB = ByteBuffer.allocateDirect(texture.length*4);
		BB.order(ByteOrder.nativeOrder());
		textureB = BB.asFloatBuffer();
		textureB.put(texture);
		textureB.position(0);
	
	
	
	


	public void move(int x, int y, int time, int width, int height) {
		if (isMoving) {
			//Log.d("targetPosition",targetX + " " + targetY);
			//Log.d("targetDandA", targetDistance + " " + targetAngle);
			if (time < moveTimer) {
				time = time + 3000;
			}
			double distance = Math.sqrt(Math.pow(targetX-xPosition,2)+Math.pow((targetY-yPosition), 2));
			if (distance > 10 ) {
				xPosition = rootX + (int)((time-moveTimer)*speed/60000*Math.cos(targetAngle));
				yPosition = rootY + (int)((time-moveTimer)*speed/60000*Math.sin(targetAngle));
				//Log.d("targetPosition",(int)((time-moveTimer)*speed*Math.cos(targetAngle))+"");
				//Log.d("targetDandA", (int)((time-moveTimer)*speed*Math.sin(targetAngle))+"");
			}
			
			if(time - moveTimer > 30) {
				isMoving = false;
			}
			
		}
		else{
			moveTimer = time;
			targetX = x;
			rootX = x;
			rootY = y;
			targetY = y;
			targetDistance = Math.sqrt(Math.pow(targetX-xPosition,2)+Math.pow((targetY-yPosition), 2));
			if(targetX-xPosition == 0) {
				targetAngle = 0;
			}
			else {
				targetAngle = Math.atan((targetY-yPosition)/(targetX-xPosition));
			}
			//Log.d("distance", (targetY-yPosition) + " " + (targetX-xPosition));
			if (targetX-xPosition < 0 && targetY-yPosition > 0) {
				targetAngle = targetAngle + (Math.PI/2 - targetAngle);
			}
			if(targetX-xPosition < 0 && targetY - yPosition < 0) {
				targetAngle = targetAngle - (Math.PI/2 + targetAngle);
			}
			//Log.d("targetDistance", targetDistance/Math.sqrt(2) + " ");
			//Log.d("targetAngle", targetAngle * 180/Math.PI + " ");
			isMoving = true;
			
		}
		/*
		if (ai == 0) {
			if (xPosition < x) {
				xPosition += s;
			}

			else if (xPosition > x) {
				xPosition -= s;
			}

			if (yPosition < y) {
				yPosition += s;
			}

			else if (yPosition > y) {
				yPosition -= s;
			}
		}
		if (ai == 1) {
			if (xPosition < x && xPosition > 10) {
				xPosition -= s;
			}

			else if (xPosition > x && xPosition < width-50) {
				xPosition += s;
			}

			if (yPosition < y && yPosition > 10) {
				yPosition -= s;
			}

			else if (yPosition > y && yPosition < height-75) {
				yPosition += s;
			}
		}

		if (ai == 2) {
			double d = Math.sqrt(Math.pow(x-xPosition,2)+Math.pow((y-yPosition), 2));
			if (d < 100) {
				if ( xPosition != x) {
					xPosition = xPosition - s*(x-xPosition)/Math.abs(xPosition-x);
				}
				if ( yPosition != y) {
					yPosition = yPosition - s*(y-yPosition)/Math.abs(yPosition-y);

				}
			}
			if (d > 120) {
				if ( xPosition != x) {
					xPosition = xPosition + s*(x-xPosition)/Math.abs(xPosition-x);
				}
				if ( yPosition != y) {
					yPosition = yPosition + s*(y-yPosition)/Math.abs(yPosition-y);
				}
			}
		}
	}
*/
}
	
	

