package edu.virginia.cs2110;

import javax.microedition.khronos.opengles.GL10;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.util.Log;

public class Hero extends Character{

	//private int xPosition, yPosition;
	private int moveTimer;
	private boolean isMoving;

	public Hero(Resources res, Bitmap b, int x, int y, float w, float h) {
		super(res, b, x, y, w, h);
		//xPosition = x;
		//yPosition = y;
	}

	public void setPosition(GL10 gl, float x, float y) {
			float dx = 0f;
			float dy = 0f;

			gl.glPushMatrix();
			if (xPosition - x > 10) {
				dx = -15f;
			}
			else if (x - xPosition > 10) {
				dx = 15f;
			}
			if (yPosition - y > 10) {
				dy = -15f;
			}
			else if (y - yPosition > 10) {
				dy = 15f;
			}
			//Log.d("Previous", xPosition + " " + yPosition);
			xPosition = xPosition + dx;
			yPosition = yPosition + dy;
			//Log.d("Next", xPosition + " " + yPosition);
			gl.glTranslatef(2*(xPosition-rootX)/w, 2*(yPosition-rootY)/h, 0f);
			draw(gl);
			gl.glPopMatrix();
			

		/*
		(2*(x+dx-width/2-w/2)/w), (2*(y+dy-height/2-h/2)/h), 0,
		(2*(x+dx-width/2-w/2)/w), (2*(y+dy+height/2-h/2)/h), 0,
		(2*(x+dx+width/2-w/2)/w), (2*(y+dy-height/2-h/2)/h) , 0,
		(2*(x+dx+width/2-w/2)/w), (2*(y+dy+height/2-h/2)/h) , 0,

		 */

	}


}
