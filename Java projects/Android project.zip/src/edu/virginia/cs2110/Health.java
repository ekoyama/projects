package edu.virginia.cs2110;

import android.support.v7.app.*;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.os.Build;

public class Health extends ImageView {
	int current = 3;
	Bitmap heart3;
	Bitmap heart2;
	Bitmap heart1;
	Bitmap heart0;

	public Health(Context context) {
		super(context);
		init();
	}

	public void init() {
		heart3 = BitmapFactory.decodeResource(getResources(),
				R.drawable.iiihearts);
		heart2 = BitmapFactory.decodeResource(getResources(),
				R.drawable.iihearts);
		heart1 = BitmapFactory.decodeResource(getResources(),
				R.drawable.ihearts);
		heart0 = BitmapFactory.decodeResource(getResources(), R.drawable.heart);
		setImageBitmap(heart3);
	}

	public void reduceBit() {
		if (current == 3)
			setImageBitmap(heart2);
		if (current == 2)
			setImageBitmap(heart1);
		if (current == 1)
			setImageBitmap(heart0);
		if (current == 0);
			//youLOSE
		invalidate();
		current --;
	}

	@Override
	public void onDraw(Canvas c) {
		super.onDraw(c);
	}
}
