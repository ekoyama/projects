package edu.virginia.cs2110;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLUtils;
import android.util.Log;

public class Character {
	protected float xPosition, yPosition, width, height, w, h;
	protected float rootX, rootY;
	protected Bitmap bit;
	protected FloatBuffer vertexB, textureB;
	protected float vertices[], texture[];
	protected int[] textures = new int[1];

	public Character(Resources res, Bitmap b, int x, int y, float w, float h) {
		bit = b;
		width = bit.getWidth();
		height = bit.getHeight();
		rootX = x;
		rootY = y;
		xPosition = x;
		yPosition = y;
		this.w = w;
		this.h = h;
		vertices = new float[] {
				(2*(x-width/2-w/2)/w), (2*(y-height/2-h/2)/h), 0,
				(2*(x-width/2-w/2)/w), (2*(y+height/2-h/2)/h), 0,
				(2*(x+width/2-w/2)/w), (2*(y-height/2-h/2)/h) , 0,
				(2*(x+width/2-w/2)/w), (2*(y+height/2-h/2)/h) , 0,
		};
		texture = new float[] {
				0f, 1f,
				0f, 0f,
				1f, 1f,
				1f, 0f,
		};
		ByteBuffer BB = ByteBuffer.allocateDirect(vertices.length*4);
		BB.order(ByteOrder.nativeOrder());
		vertexB = BB.asFloatBuffer();
		vertexB.put(vertices);
		vertexB.position(0);

		BB = ByteBuffer.allocateDirect(texture.length*4);
		BB.order(ByteOrder.nativeOrder());
		textureB = BB.asFloatBuffer();
		textureB.put(texture);
		textureB.position(0);
	}

	public int getxPosition() {
		return (int) xPosition;
	}

	public void setxPosition(int xPosition) {
		this.xPosition = xPosition;
	}

	public int getyPosition() {
		return (int) yPosition;
	}

	public void setyPosition(int yPosition) {
		this.yPosition = yPosition;
	}
	
	public float getRootX() {
		return rootX;
	}
	
	public float getRootY() {
		return rootY;
	}

	public float getWidth() {
		return width;
	}

	public float getHeight() {
		return height;
	}

	public String toString() {
		return "Position: [" + xPosition + ", " + yPosition + "]";
	}

	public void draw(GL10 gl) {
		gl.glBindTexture(GL10.GL_TEXTURE_2D, textures[0]);
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		//gl.glScalef(0.5f, 0.5f, 0.5f);
		//gl.glColor4f(0.0f, 0f, 0f, 0.5f);
		gl.glFrontFace(GL10.GL_CW);
		gl.glVertexPointer(3,GL10.GL_FLOAT,0,vertexB);
		gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, textureB);
		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, vertices.length / 3);
		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
	}

	public void loadGLTexture(GL10 gl, Context context) {
		gl.glGenTextures(1, textures, 0);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, textures[0]);
		gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_NEAREST);
		gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_LINEAR);
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bit, 0);

		/*
	    vertices = new float[] {
					-x/(2*w), -y/(2*h), 0.0f,
					-x/(2*w), -y/(2*h)+height/(2*h), 0.0f,
					-x/(2*w)+width/(2*w), -y/(2*h), 0.0f,
					-x/(2*w)+width/(2*w), -y/(2*h)+height/(2*h), 0.0f
		};
	    texture = new float[] {
	    		-x/(2*w), -y/(2*h), 0.0f,
	    		-x/(2*w)+width/(2*w), -y/(2*h), 0.0f,
				-x/(2*w), -y/(2*h)+height/(2*h), 0.0f,
				-x/(2*w)+width/(2*w), -y/(2*h)+height/(2*h), 0.0f

	    };


	    -x/(2*w), -y/(2*h), 0.0f,
	    		x/(2*w), -y/(2*h), 0.0f,
				-x/(2*w), y/(2*h), 0.0f,
				x/(2*w), y/(2*h), 0.0f
		 */


	}
}
