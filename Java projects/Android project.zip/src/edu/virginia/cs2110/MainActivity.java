package edu.virginia.cs2110;

import java.util.*;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import com.google.gson.Gson;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.view.*;
import android.widget.Button;


public class MainActivity extends Activity {
	int t;
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_splash_screen);
		
		new Handler().postDelayed(new Runnable() {

	        @Override
	        public void run() {
	        	init();
	        }
	    }, 3000);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	    // Inflate the menu items for use in the action bar
	    MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.main, menu);
	    return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    // Handle presses on the action bar items
	    switch (item.getItemId()) {
	        case R.id.save:
	            save();
	            return true;
	        default:
	            return super.onOptionsItemSelected(item);
	    }
	}
	
	public void init() {
		setContentView(R.layout.activity_main);
		getWindow().setBackgroundDrawableResource(R.drawable.dw_spooky_manor);
		
		Button startGame = (Button) findViewById(R.id.button1);
		Button loadGame = (Button) findViewById(R.id.load_button);
		
		
		final View vw = new MainView(this);
		startGame.setOnClickListener(new View.OnClickListener() {
	            public void onClick(View v) {
	            	getWindow().setBackgroundDrawableResource(R.drawable.dw_spooky_manor);
	                setContentView(vw);
	            }
		});
		final View v2 = new MainView(this,0);
		loadGame.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	getWindow().setBackgroundDrawableResource(R.drawable.dw_spooky_manor);
            	load((MainView)v2);
            	setContentView(v2);
            }
	});
	}
	
	public void save()
	{
		SharedPreferences sharedPref = this.getPreferences(Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPref.edit();
		
		Set<String> ghostString = new HashSet<String>();
		View view = this.getCurrentFocus();
		Gson gson = new Gson();
		//Saves data from MainView
		if(view instanceof MainView)
		{
		ArrayList<Ghost> ghosts = ((MainView) view).getGhosts();
		gson.toJson(ghosts);
		editor.putString("ghosts", gson.toJson(ghosts));
		
		Hero hero = ((MainView) view).getHero();
		editor.putString("hero", gson.toJson(hero));
		
		/*Character character = ((MainView) view).getCharacter();
		editor.putString("character", gson.toJson(character));
		*/
		/**
		int score = ((Main View) view).getScore();
		editor.putInt("score", score);
		
		float time = ((Main View) view).getTime();
		editor.putFloat("time", time);
		 
		 int health = ((Main View) view).getHealth();
		 editor.putInt("health", health);
		*/
		}
		
		
		editor.commit();
	}
	
	public void load(MainView mv)
	{
		SharedPreferences sharedPref = this.getPreferences(Context.MODE_PRIVATE);
		Gson gson = new Gson();
		
			String ghosts = sharedPref.getString("ghosts", "");
			ArrayList<Ghost> g = gson.fromJson(ghosts, ArrayList.class);
			mv.setGhosts(g);
			
			String hero = sharedPref.getString("hero", "");
			Hero h = gson.fromJson(hero, Hero.class);
			mv.setHero(h);
			
			/*String character = sharedPref.getString("character", "");
			Character ch = gson.fromJson(character, Character.class);
			mv.setCharacter(ch);
			*/
			
			int health = sharedPref.getInt("health", 0);
			//put health, time, score same way. figure out defaults. figure out load key (work w/ Evaristo on Unique button press to establish new view).
		
	}
	

	
}





