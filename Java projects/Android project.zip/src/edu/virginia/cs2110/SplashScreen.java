package edu.virginia.cs2110;

import android.app.Activity;
import android.os.Bundle;

public class SplashScreen extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	}

}
