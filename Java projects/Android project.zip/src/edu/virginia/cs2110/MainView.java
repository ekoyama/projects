package edu.virginia.cs2110;

//import android.support.v7.app.ActionBarActivity;
//import android.support.v7.app.ActionBar;
//import android.support.v4.app.Fragment;
import java.util.ArrayList;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.opengl.GLSurfaceView;
import android.opengl.GLU;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.WindowManager;

public class MainView extends GLSurfaceView {
	public Bitmap bit;
	private DisplayMetrics disp;
	private Context cn;
	private float width, height, x, y, frameRate, time;
	private float t;
	private final static int fps = 60;
	private final static int f_skips = 5;
	private final static int f_period = 1000/f_skips;
	private Character ch;
	private Hero h;
	private ArrayList<Ghost> gh;
	//g1, g2, g3, g4, g5, g6;

	private Paint p;

	public void load()
	{
		x = h.getxPosition();
		y = h.getyPosition();
		disp = new DisplayMetrics();
		((WindowManager) cn.getSystemService(Context.WINDOW_SERVICE))
		.getDefaultDisplay().getMetrics(disp);
		
		width = disp.widthPixels;
		height = disp.heightPixels;
		time = 0;
		t = -5f;
	}
	
	public ArrayList<Ghost> getGhosts()
	{
		return gh;
	}
	public void setGhosts(ArrayList<Ghost> ghosts)
	{
		gh = ghosts;
	}
	
	public Character getCharacter()
	{
		return ch;
	}
	public void setCharacter(Character character)
	{
		ch = character;	
	}
	
	public Hero getHero()
	{
		return h;
	}
	public void setHero(Hero hero)
	{
		h = hero;
	}
	
	public MainView(Context c, int x)
	{
		super(c);
		cn = c;
		setRenderer(new GameRenderer());
	}
	
	public MainView(Context c) {
		super(c);
		cn = c;
		setRenderer(new GameRenderer());
		init();
	}

	public MainView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setRenderer(new GameRenderer());
		init();
		// TODO Auto-generated constructor stub
	}

	public void setRefreshRate(int fr) {
		frameRate = fr;
	}

	
	
	public void init() {
		disp = new DisplayMetrics();
		((WindowManager) cn.getSystemService(Context.WINDOW_SERVICE))
		.getDefaultDisplay().getMetrics(disp);
		x = 100;
		y = 100;
		time = 0;
		t = -5f;
		width = disp.widthPixels;
		height = disp.heightPixels;
		Bitmap bit_h = BitmapFactory.decodeResource(getResources(),
				R.drawable.ic_launcher);
		Bitmap bit_g1 = BitmapFactory.decodeResource(getResources(), 
				R.drawable.duskball);
		bit_g1 = Bitmap.createScaledBitmap(bit_g1, 48, 48, true);
		gh = new ArrayList<Ghost>();

		//ch = new Character(getResources(),bit_ch, 400, 613, width, height, t);
		h = new Hero(getResources(), bit_h, 100, 100, width, height);
		gh.add(new Ghost(getResources(), bit_g1, 500, 500, width, height, 0, 10));
		gh.add(new Ghost(getResources(), bit_g1, 100, 613, width, height, 1, 9));
		gh.add(new Ghost(getResources(), bit_g1, 100, 713, width, height, 2, 7));
		gh.add(new Ghost(getResources(), bit_g1, 100, 813, width, height, 0, 5));
		gh.add(new Ghost(getResources(), bit_g1, 100, 913, width, height, 2, 3));
		gh.add(new Ghost(getResources(), bit_g1, 100, 1113, width, height, 2, 2));
		
		
		/**
		p = new Paint();
		p.setARGB(255, 255, 0, 0);
		p.setStyle(Paint.Style.STROKE);
		p.setStrokeWidth(5);
		 */
	}
	
	public boolean onTouchEvent(MotionEvent e) {
		if(e.getAction() == MotionEvent.ACTION_DOWN){
			x = (3*e.getX()/2 -200);
			y = (float) (1874.8-2.27*e.getY());
		}
		return true;
	}


	/*
	@Override
	public void onDraw(Canvas c) {
		super.onDraw(c);
		time = (time+1)%(1000*frameRate);

		c.drawCircle(x, y, 10, p);
		//g1.draw(c, x, y, time, width, height);
		//g2.draw(c, x, y, time, width, height);
		//g3.draw(c, x, y, time, width, height);
		invalidate();
	}*/

	private class GameRenderer implements GLSurfaceView.Renderer {

		public void onDrawFrame(GL10 gl) {

			gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
			gl.glLoadIdentity();

			gl.glTranslatef(0.0f, 0.0f, -5.0f);
			
			
			h.setPosition(gl, x, y);
			
			for(Ghost g : gh) {
				g.move(gl, h);
			}
			time += (time+1)%3000;
		}

		@Override
		public void onSurfaceChanged(GL10 gl, int width, int height) {

			gl.glViewport(0, 0, width, height); 	//Reset The Current Viewport
			gl.glMatrixMode(GL10.GL_PROJECTION); 	//Select The Projection Matrix
			gl.glLoadIdentity(); 					//Reset The Projection Matrix

			//Calculate The Aspect Ratio Of The Window
			GLU.gluPerspective(gl, 45.0f, (float)width / (float)height, 0.1f, 100.0f);

			gl.glMatrixMode(GL10.GL_MODELVIEW); 	//Select The Modelview Matrix
			gl.glLoadIdentity(); 

			//gl.glClearColor(0.0f, 0.0f, 0.0f, 0.5f); //background
		}

		@Override
		public void onSurfaceCreated(GL10 gl, EGLConfig config) {
			gl.glEnable(GL10.GL_TEXTURE_2D);
			gl.glShadeModel(GL10.GL_SMOOTH);
			//gl.glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
			gl.glClearDepthf(1.0f); 					
			gl.glEnable(GL10.GL_DEPTH_TEST); 			
			gl.glDepthFunc(GL10.GL_LEQUAL);
			h.loadGLTexture(gl, cn);
			for(Ghost g : gh) {
				g.loadGLTexture(gl, cn);
			}
		}
	}
}
