insert into Model(name, brand_name) values("Highlander", "Toyota");
insert into Model(name, brand_name) values("Prius", "Toyota");
insert into Model(name, brand_name) values("Camry", "Toyota");
insert into Model(name, brand_name) values("Corolla", "Toyota");

insert into Model(name, brand_name) values("Yukon", "GMC");
insert into Model(name, brand_name) values("Canyon", "GMC");

insert into Model(name, brand_name) values("Cherokee", "Jeep");
insert into Model(name, brand_name) values("Compass", "Jeep");

insert into Model(name, brand_name) values("F-150", "Ford");
insert into Model(name, brand_name) values("Fusion", "Ford");
      