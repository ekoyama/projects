('admin',UNHEX("892a550c05b37989f36d9a5164987269f5dc359143c078d120ec2143055de152"),'Dbmanager','4342020000','root@db.com', 22903, CURDATE(), 'DBManager', CURDATE());
('alice',UNHEX("895b06c5f5e2ee839384ae47b77617d3a072c05d180cdbcbc174f8fcb825cebc"),'Alice','4342025555','alice@db.com',22904,'Customer', CURDATE());
('bob', UNHEX("90b7d08052db35047df8988d53f8984313237187a1fd0eb8899f3a4e1a323f57"),'Bob','4342026666','bob@db.com',22905,'Customer', CURDATE());
('jason',UNHEX("7b29c348623fd10b97c19e87e60b562f1ce3d896979ac455d52a384d9359c53b"),'Jason','4342024444','jason@db.com',22903,'Customer', CURDATE());
('brown',UNHEX("86589084b822a49d9ac514724b64371c7f859b13f6e920e850a6efe93a6c5eec"),'Brown','4342022222','brown@db.com',22901,'Dealer', CURDATE());
('dealer1',UNHEX("0b21c8a0250035bf0d3f16b27a6d619916b8ac278cf29c0d103f845ec2a58d5e"),'CarFAX','4342021111','carfax@db.com',22904,'Dealer', CURDATE());
('dealer2',UNHEX("bdccbad8ce2b31272bd7b79dbdbdcec771b0a802831fa9f9a8990fd841615375"),'Uva','4342023333','uva@db.com',22903,'Dealer', CURDATE());







